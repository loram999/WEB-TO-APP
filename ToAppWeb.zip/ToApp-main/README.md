# 🌐 Web Konvert Web to APK via API Bagus

Sebuah proyek sederhana yang memanfaatkan Api Bagus Xixpen, **https://web2apk-cg.zone.id/tools/web2app?**

---

## 🚀 Fitur 

- 🔄 Konversi website ke APK

- ☁️ Bisa dijalankan di localhost, Vercel, Netlify, dan platform lainnya

---

# Thx To
- Bagus ( penyedia api )

_Ngga Usah Jual Atau Hapus WM Suki Pakai aja kalau mau_
